<?php
namespace sg\data;

use pocketmine\block\Block;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;

/**
 * Contains coords for tournament and team tiles in lobby,
 * also checks for sign type (ic tournament, is team etc.) are here
 * main variable is an array of map data (pedestal and deathmatch coords for each arena)
 */
class PluginData {
	
	/*tournament tile coords*/
	private static $tournamentTiles = array(
		"xFirst" => -12,
		"xLast" => -8,
		"y" => 36,
		"z" => 14
	);
	
	/*vip team tiles coords*/
	private static $teamTileCoords = array(
		"xLeft" => -18,
		"xRight" => -2,
		"z" => 11
	);
	/*contains y coord as key and team color as value*/
	private static $TeamByCoordY = array(
		"37" => "red",
		"36" => "green",
		"35" => "blue"
	);
	
	/*coords of map signs in lobby*/
	public static $mapSignCoords = array(
		1 => array(-8, 36, 14),
		2 => array(-9, 36, 14),
		3 => array(-10, 36, 14),
		4 => array(-11, 36, 14),
		5 => array(-12, 36, 14)
	);
	
	/*map sign info when plugin starts*/
	public static $defaultSignData = array(
		array(TextFormat::DARK_AQUA . "[Starting...]", "", "", ""),
		array("---", "", "", ""),
		array("---", "", "", ""),
		array("---", "", "", ""),
		array("---", "", "", "")
	);
	
	/*big jump redTiles coords*/
	public static $redTiles = array(
		1 => array("x" => -10, "z" => -15),
		2 => array("x" => -2, "z" => -23),
		3 => array("x" => -18, "z" => -23)
	);
	
	/* breakable blocks like grass */
	public static $whitelistedBlocks = array(
		Block::TNT => true,
		Block::LEAVES => true,
		Block::COBWEB => true,
		Block::TALL_GRASS => true,
		Block::BUSH => true,
		Block::BROWN_MUSHROOM => true,
		Block::RED_MUSHROOM => true,
		Block::GLASS_PANEL => true,
		Block::CAKE_BLOCK => true,
		Block::TORCH => true
	);
	
	/* map names for signs */
	public static $mapNames = array(
		'1' => 'SG Highway',
		'2' => 'Alaskan Village',
		'3' => 'Breeze Island',
		'4' => 'Moonlight Lake',
		'5' => 'Breeze Island 2',
		'6' => 'The Alps',
		'7' => 'Zone 85',
		'8' => 'SG IV',
		'9' => 'Ant Mound',
		'10' => 'Howling Mountains',
		'11' => 'Salad Frost',
		'12' => 'Drybone Valley',
		'13' => 'Akupu Shores',
		'14' => 'Hunger Caves',
		'15' => 'Snowbound',
		'16' => 'Origins',
		'17' => 'Fortress Pyke',
		'18' => 'Moonbase 9',
		'19' => 'Turbulence',
		'20' => 'Holiday Resort',
		'21' => 'Excavation Zero'
	);
 
	/*all map pedestal & deathmatch coords*/
	public static $mapData = array(
		'1' => array(
			'author' => 'static_nightmare',
			'deathmatch' => array(6, 117, 608),
			'pedestals' => array(
				array(6, 44, 588),
				array(1, 44, 589),
				array(-4, 44, 591),
				array(-8, 44, 594),
				array(-11, 44, 598),
				array(-13, 44, 603),
				array(-14, 44, 608),
				array(-13, 44, 613),
				array(-11, 44, 618),
				array(-8, 44, 622),
				array(-4, 44, 625),
				array(1, 44, 627),
				array(6, 44, 628),
				array(11, 44, 627),
				array(16, 44, 625),
				array(20, 44, 622),
				array(23, 44, 618),
				array(25, 44, 613),
				array(26, 44, 608),
				array(25, 44, 603),
				array(23, 44, 598),
				array(20, 44, 594),
				array(16, 44, 591),
				array(11, 44, 589),
			)
		),
		'2' => array(
			'author' => 'Discovery Works',
			'deathmatch' => array(33, 117, 1264),
			'pedestals' => array(
				array(57, 37, 1264),
				array(56, 37, 1272),
				array(53, 37, 1277),
				array(50, 37, 1281),
				array(46, 37, 1284),
				array(41, 37, 1287),
				array(33, 37, 1288),
				array(25, 37, 1287),
				array(20, 37, 1284),
				array(16, 37, 1281),
				array(13, 37, 1277),
				array(10, 37, 1272),
				array(9, 37, 1264),
				array(10, 37, 1256),
				array(13, 37, 1251),
				array(16, 37, 1247),
				array(20, 37, 1244),
				array(25, 37, 1241),
				array(33, 37, 1240),
				array(41, 37, 1241),
				array(46, 37, 1244),
				array(50, 37, 1247),
				array(53, 37, 1251),
				array(56, 37, 1256),
			)
		),
		'3' => array(
			'author' => 'static_nightmare',
			'deathmatch' => array(686, 117, 1258),
			'pedestals' => array(
				array(668, 18, 1276),
				array(664, 18, 1270),
				array(662, 18, 1264),
				array(661, 18, 1258),
				array(662, 18, 1252),
				array(664, 18, 1246),
				array(668, 18, 1240),
				array(674, 18, 1236),
				array(680, 18, 1234),
				array(686, 18, 1233),
				array(692, 18, 1234),
				array(698, 18, 1236),
				array(704, 18, 1240),
				array(708, 18, 1246),
				array(710, 18, 1252),
				array(711, 18, 1258),
				array(710, 18, 1264),
				array(708, 18, 1271),
				array(704, 18, 1276),
				array(698, 18, 1280),
				array(692, 18, 1282),
				array(686, 18, 1283),
				array(680, 18, 1282),
				array(674, 18, 1280)
			)
		),
		'4' => array(
			'author' => 'GuyK',
			'deathmatch' => array(-508, 117, 513),
			'pedestals' => array(
				array(-483, 4, 513),
				array(-484, 4, 519),
				array(-486, 4, 526),
				array(-490, 4, 532),
				array(-496, 4, 535),
				array(-502, 4, 537),
				array(-508, 4, 538),
				array(-514, 4, 537),
				array(-521, 4, 535),
				array(-527, 4, 531),
				array(-530, 4, 525),
				array(-532, 4, 519),
				array(-533, 4, 513),
				array(-532, 4, 507),
				array(-530, 4, 501),
				array(-527, 4, 495),
				array(-521, 4, 491),
				array(-514, 4, 488),
				array(-508, 4, 487),
				array(-502, 4, 488),
				array(-496, 4, 491),
				array(-490, 4, 495),
				array(-486, 4, 501),
				array(-484, 4, 507)
			)
		),
		'5' => array(
			'author' => 'static_nightmare',
			'deathmatch' => array(4, 106, -601),
			'pedestals' => array(
				array(20, 13, -617),
				array(15, 13, -621),
				array(10, 13, -623),
				array(4, 13, -624),
				array(-2, 13, -623),
				array(-7, 13, -621),
				array(-12, 13, -617),
				array(-16, 13, -612),
				array(-18, 13, -607),
				array(-19, 13, -601),
				array(-18, 13, -595),
				array(-16, 13, -590),
				array(-12, 13, -585),
				array(-7, 13, -581),
				array(-2, 13, -579),
				array(4, 13, -578),
				array(10, 13, -579),
				array(15, 13, -581),
				array(20, 13, -585),
				array(24, 13, -590),
				array(26, 13, -595),
				array(27, 13, -601),
				array(26, 13, -607),
				array(24, 13, -612),
			)
		),
		'6' => array(
			'author' => 'Tengus',
			'deathmatch' => array(3206, 107, 3325),
			'pedestals' => array(
				array(3223, 19, 3325),
				array(3222, 19, 3321),
				array(3220, 19, 3317),
				array(3218, 19, 3313),
				array(3214, 19, 3311),
				array(3211, 19, 3308),
				array(3206, 19, 3308),
				array(3202, 19, 3309),
				array(3198, 19, 3311),
				array(3194, 19, 3313),
				array(3192, 19, 3317),
				array(3189, 19, 3320),
				array(3189, 19, 3325),
				array(3189, 19, 3330),
				array(3192, 19, 3333),
				array(3194, 19, 3337),
				array(3198, 19, 3339),
				array(3201, 19, 3342),
				array(3206, 19, 3342),
				array(3210, 19, 3341),
				array(3214, 19, 3339),
				array(3218, 19, 3337),
				array(3220, 19, 3333),
				array(3222, 19, 3329),
			)
		),
		'7' => array(
			'author' => 'SuperxAndrew',
			'deathmatch' => array(677, 117, -621),
			'pedestals' => array(
				array(677, 35, -600),
				array(682, 35, -601),
				array(688, 35, -603),
				array(692, 35, -606),
				array(695, 35, -610),
				array(697, 35, -616),
				array(698, 35, -621),
				array(697, 35, -626),
				array(695, 35, -632),
				array(692, 35, -636),
				array(688, 35, -639),
				array(682, 35, -641),
				array(677, 35, -642),
				array(672, 35, -641),
				array(666, 35, -639),
				array(662, 35, -636),
				array(659, 35, -632),
				array(657, 35, -626),
				array(656, 35, -621),
				array(657, 35, -616),
				array(659, 35, -610),
				array(662, 35, -606),
				array(666, 35, -603),
				array(672, 35, -601),
			)
		),
		'8' => array(
			'author' => 'Vareide',
			'deathmatch' => array(-600, 117, -48),
			'pedestals' => array(
				array(-583, 31, -48),
				array(-583, 31, -44),
				array(-585, 31, -40),
				array(-588, 31, -36),
				array(-592, 31, -33),
				array(-596, 31, -31),
				array(-600, 31, -31),
				array(-604, 31, -31),
				array(-608, 31, -33),
				array(-612, 31, -36),
				array(-615, 31, -40),
				array(-617, 31, -44),
				array(-617, 31, -48),
				array(-617, 31, -52),
				array(-615, 31, -56),
				array(-612, 31, -60),
				array(-608, 31, -63),
				array(-604, 31, -65),
				array(-600, 31, -65),
				array(-596, 31, -65),
				array(-592, 31, -63),
				array(-588, 31, -60),
				array(-585, 31, -56),
				array(-583, 31, -52)
			)
		),
		'9' => array(
			'author' => 'Kaelinator',
			'deathmatch' => array(-1097, 117, 533),
			'pedestals' => array(
				array(-1098, 62, 509),
				array(-1105, 62, 511),
				array(-1110, 62, 514),
				array(-1115, 62, 516),
				array(-1118, 62, 521),
				array(-1121, 62, 526),
				array(-1122, 62, 533),
				array(-1120, 62, 538),
				array(-1117, 62, 543),
				array(-1113, 62, 548),
				array(-1108, 62, 553),
				array(-1104, 62, 556),
				array(-1098, 62, 557),
				array(-1091, 62, 556),
				array(-1086, 62, 553),
				array(-1082, 62, 549),
				array(-1078, 62, 545),
				array(-1075, 62, 539),
				array(-1074, 62, 533),
				array(-1076, 62, 528),
				array(-1079, 62, 522),
				array(-1083, 62, 518),
				array(-1086, 62, 514),
				array(-1092, 62, 511),
			)
		),
		'10' => array(
			'author' => 'Teweran',
			'deathmatch' => array(-622, 110, -658),
			'pedestals' => array(
				array(-608, 12, -628),
				array(-613, 12, -629),
				array(-618, 12, -631),
				array(-622, 12, -634),
				array(-625, 12, -638),
				array(-627, 12, -643),
				array(-628, 12, -648),
				array(-627, 12, -653),
				array(-625, 12, -658),
				array(-622, 12, -662),
				array(-618, 12, -665),
				array(-613, 12, -667),
				array(-608, 12, -668),
				array(-603, 12, -667),
				array(-598, 12, -665),
				array(-594, 12, -662),
				array(-591, 12, -658),
				array(-589, 12, -653),
				array(-588, 12, -648),
				array(-589, 12, -643),
				array(-591, 12, -638),
				array(-594, 12, -634),
				array(-598, 12, -631),
				array(-603, 12, -629),
			)
		),
		'11' => array(
			'author' => 'Echo_555',
			'deathmatch' => array(-1094, 89, -100),
			'pedestals' => array(
				array(-1062, 4, -114),
				array(-1063, 4, -108),
				array(-1065, 4, -101),
				array(-1070, 4, -95),
				array(-1076, 4, -90),
				array(-1083, 4, -88),
				array(-1089, 4, -87),
				array(-1095, 4, -88),
				array(-1102, 4, -90),
				array(-1108, 4, -95),
				array(-1113, 4, -101),
				array(-1115, 4, -108),
				array(-1116, 4, -114),
				array(-1115, 4, -120),
				array(-1113, 4, -127),
				array(-1108, 4, -133),
				array(-1102, 4, -138),
				array(-1095, 4, -140),
				array(-1089, 4, -141),
				array(-1083, 4, -140),
				array(-1076, 4, -138),
				array(-1070, 4, -133),
				array(-1065, 4, -127),
				array(-1063, 4, -120)
			)
		),
		'12' => array(
			'author' => 'Teweran',
			'deathmatch' => array(3634, 112, -1989),
			'pedestals' => array(
				array(3653, 17, -1994),
				array(3654, 17, -1989),
				array(3653, 17, -1984),
				array(3651, 17, -1979),
				array(3648, 17, -1975),
				array(3644, 17, -1972),
				array(3639, 17, -1970),
				array(3634, 17, -1969),
				array(3629, 17, -1970),
				array(3624, 17, -1972),
				array(3620, 17, -1975),
				array(3617, 17, -1979),
				array(3615, 17, -1984),
				array(3614, 17, -1989),
				array(3615, 17, -1994),
				array(3617, 17, -1999),
				array(3620, 17, -2003),
				array(3624, 17, -2006),
				array(3629, 17, -2008),
				array(3634, 17, -2009),
				array(3639, 17, -2008),
				array(3644, 17, -2006),
				array(3648, 17, -2003),
				array(3651, 17, -1999)
			)
		),
		'13' => array(
			'author' => 'Madkaramoto',
			'deathmatch' => array(-2861, 117, -1085),
			'pedestals' => array(
				array(-2880, 32, -1080),
				array(-2881, 32, -1085),
				array(-2880, 32, -1090),
				array(-2878, 32, -1095),
				array(-2875, 32, -1099),
				array(-2871, 32, -1102),
				array(-2866, 32, -1104),
				array(-2861, 32, -1105),
				array(-2856, 32, -1104),
				array(-2851, 32, -1102),
				array(-2847, 32, -1099),
				array(-2844, 32, -1095),
				array(-2842, 32, -1090),
				array(-2841, 32, -1085),
				array(-2842, 32, -1080),
				array(-2844, 32, -1075),
				array(-2847, 32, -1071),
				array(-2851, 32, -1068),
				array(-2856, 32, -1066),
				array(-2861, 32, -1065),
				array(-2866, 32, -1066),
				array(-2871, 32, -1068),
				array(-2875, 32, -1071),
				array(-2878, 32, -1075)
			)
		),
		'14' => array(
			'author' => 'The_MC_Creep',
			'deathmatch' => array(2816, 90, 3328),
			'pedestals' => array(
				array(2796, 7, 3328),
				array(2796, 7, 3323),
				array(2798, 7, 3318),
				array(2802, 7, 3314),
				array(2806, 7, 3311),
				array(2811, 7, 3308),
				array(2816, 7, 3308),
				array(2822, 7, 3309),
				array(2826, 7, 3311),
				array(2830, 7, 3314),
				array(2834, 7, 3318),
				array(2836, 7, 3323),
				array(2836, 7, 3328),
				array(2835, 7, 3334),
				array(2833, 7, 3338),
				array(2830, 7, 3342),
				array(2826, 7, 3345),
				array(2821, 7, 3348),
				array(2816, 7, 3348),
				array(2810, 7, 3348),
				array(2806, 7, 3346),
				array(2802, 7, 3342),
				array(2799, 7, 3338),
				array(2796, 7, 3333)
			)
		),
		'15' => array(
			'author' => 'Reevesdrums',
			'deathmatch' => array(2710, 21, 2875),
			'pedestals' => array(
				array(2829, 14, 2952),
				array(2830, 14, 2947),
				array(2832, 14, 2942),
				array(2835, 14, 2938),
				array(2839, 14, 2935),
				array(2844, 14, 2933),
				array(2849, 14, 2932),
				array(2854, 14, 2933),
				array(2859, 14, 2935),
				array(2863, 14, 2938),
				array(2866, 14, 2942),
				array(2868, 14, 2947),
				array(2869, 14, 2952),
				array(2868, 14, 2957),
				array(2866, 14, 2962),
				array(2863, 14, 2966),
				array(2859, 14, 2969),
				array(2854, 14, 2971),
				array(2849, 14, 2972),
				array(2844, 14, 2971),
				array(2839, 14, 2969),
				array(2835, 14, 2966),
				array(2832, 14, 2962),
				array(2830, 14, 2957)
			)
		),
		'16' => array(
			'author' => 'darkflame2308',
			'deathmatch' => array(3200, 109, 2944),
			'pedestals' => array(
				array(3214, 71, 2939),
				array(3215, 71, 2942),
				array(3215, 71, 2947),
				array(3214, 71, 2950),
				array(3212, 71, 2953),
				array(3208, 71, 2957),
				array(3205, 71, 2959),
				array(3202, 71, 2960),
				array(3197, 71, 2960),
				array(3194, 71, 2959),
				array(3191, 71, 2957),
				array(3187, 71, 2954),
				array(3185, 71, 2950),
				array(3184, 71, 2947),
				array(3184, 71, 2942),
				array(3188, 71, 2939),
				array(3187, 71, 2936),
				array(3191, 71, 2932),
				array(3194, 71, 2930),
				array(3197, 71, 2929),
				array(3202, 71, 2929),
				array(3205, 71, 2930),
				array(3208, 71, 2932),
				array(3212, 71, 2936)
			)
		),
		'17' => array(
			'author' => 'xBayani',
			'deathmatch' => array(3761, 117, 3206),
			'pedestals' => array(
				array(3761, 70, 3178),
				array(3768, 70, 3179),
				array(3775, 70, 3182),
				array(3781, 70, 3186),
				array(3785, 70, 3192),
				array(3788, 70, 3199),
				array(3789, 70, 3206),
				array(3788, 70, 3214),
				array(3785, 70, 3220),
				array(3781, 70, 3226),
				array(3775, 70, 3230),
				array(3768, 70, 3233),
				array(3761, 70, 3234),
				array(3754, 70, 3233),
				array(3747, 70, 3230),
				array(3741, 70, 3226),
				array(3737, 70, 3220),
				array(3734, 70, 3213),
				array(3733, 70, 3206),
				array(3734, 70, 3199),
				array(3737, 70, 3192),
				array(3741, 70, 3186),
				array(3747, 70, 3182),
				array(3754, 70, 3179),
			)
		),
		'18' => array(
			'author' => 'Ninetailefox92',
			'deathmatch' => array(-3066, 73, -2043),
			'pedestals' => array(
				array(-3066, 20, -2075),
				array(-3074, 20, -2073),
				array(-3082, 20, -2071),
				array(-3089, 20, -2066),
				array(-3094, 20, -2059),
				array(-3096, 20, -2051),
				array(-3098, 20, -2043),
				array(-3096, 20, -2035),
				array(-3094, 20, -2027),
				array(-3089, 20, -2020),
				array(-3082, 20, -2015),
				array(-3074, 20, -2013),
				array(-3066, 20, -2011),
				array(-3058, 20, -2013),
				array(-3050, 20, -2015),
				array(-3043, 20, -2020),
				array(-3038, 20, -2027),
				array(-3036, 20, -2035),
				array(-3034, 20, -2043),
				array(-3036, 20, -2051),
				array(-3038, 20, -2059),
				array(-3043, 20, -2066),
				array(-3050, 20, -2071),
				array(-3058, 20, -2073),
			)
		),
		'19' => array(
			'author' => 'cadbane4321',
			'deathmatch' => array(-2388, 113, 3211),
			'pedestals' => array(
				array(-2352, 53, 3167),
				array(-2352, 53, 3173),
				array(-2353, 53, 3178),
				array(-2356, 53, 3183),
				array(-2360, 53, 3187),
				array(-2365, 53, 3190),
				array(-2371, 53, 3192),
				array(-2377, 53, 3192),
				array(-2382, 53, 3191),
				array(-2387, 53, 3188),
				array(-2391, 53, 3184),
				array(-2394, 53, 3179),
				array(-2396, 53, 3173),
				array(-2396, 53, 3167),
				array(-2395, 53, 3162),
				array(-2392, 53, 3157),
				array(-2388, 53, 3153),
				array(-2382, 53, 3149),
				array(-2377, 53, 3148),
				array(-2371, 53, 3148),
				array(-2366, 53, 3149),
				array(-2361, 53, 3152),
				array(-2357, 53, 3156),
				array(-2354, 53, 3161),
			)
		),
		'20' => array(
			'author' => 'Simey',
			'deathmatch' => array(-1841, 68, 3380),
			'pedestals' => array(
				array(-1621, 72, 3158),
				array(-1616, 72, 3159),
				array(-1611, 72, 3161),
				array(-1607, 72, 3164),
				array(-1604, 72, 3168),
				array(-1602, 72, 3173),
				array(-1601, 72, 3178),
				array(-1602, 72, 3183),
				array(-1604, 72, 3188),
				array(-1607, 72, 3192),
				array(-1611, 72, 3195),
				array(-1616, 72, 3197),
				array(-1621, 72, 3198),
				array(-1626, 72, 3197),
				array(-1631, 72, 3195),
				array(-1635, 72, 3192),
				array(-1638, 72, 3188),
				array(-1640, 72, 3183),
				array(-1641, 72, 3178),
				array(-1640, 72, 3173),
				array(-1638, 72, 3168),
				array(-1635, 72, 3164),
				array(-1631, 72, 3161),
				array(-1626, 72, 3159),
			)
		),
		'21' => array(
			'author' => 'Aktikon',
			'deathmatch' => array(668, 136, -24),
			'pedestals' => array(
				array(668, 10, -44),
				array(673, 10, -43),
				array(678, 10, -41),
				array(682, 10, -38),
				array(685, 10, -34),
				array(687, 10, -29),
				array(688, 10, -24),
				array(687, 10, -19),
				array(685, 10, -14),
				array(682, 10, -10),
				array(678, 10, -7),
				array(673, 10, -5),
				array(668, 10, -4),
				array(663, 10, -5),
				array(658, 10, -7),
				array(654, 10, -10),
				array(651, 10, -14),
				array(649, 10, -19),
				array(648, 10, -24),
				array(649, 10, -29),
				array(651, 10, -34),
				array(654, 10, -38),
				array(658, 10, -41),
				array(663, 10, -43),
			)
		)
	);
	
	/*items allowed in chests*/
	public static $chestItems = array(
		array(Item::BREAD, 45, true),
		array(Item::COOKED_PORKCHOP, 60, true),
		array(Item::COOKED_CHICKEN, 90, true),
		array(Item::CAKE, 120, false),
		array(Item::BOWL, 135, true),
		array(Item::STEAK, 165, true),
		array(Item::APPLE, 175, true),
		array(Item::RAW_CHICKEN, 180, true),
		array(Item::RAW_PORKCHOP, 195, true),
		array(Item::RAW_BEEF, 210, true),
		array(Item::RED_MUSHROOM, 225, true),
		array(Item::BROWN_MUSHROOM, 240, true),
		array(Item::CARROT, 255, true),
		array(Item::POTATO, 270, true),
		array(Item::BAKED_POTATO, 300, true),
		array(Item::WOODEN_AXE, 330, false),
		array(Item::STONE_AXE, 355, false),
		array(Item::GOLD_AXE, 375, false),
		array(Item::IRON_AXE, 390, false),
		array(Item::STICK, 470, false),
		array(Item::WOODEN_SWORD, 480, false),
		array(Item::STONE_SWORD, 560, false),
		array(Item::GOLD_SWORD, 600, false),
		array(Item::FLINT_AND_STEEL, 620, false),
		array(Item::BUCKET, 630, true),
		array(Item::IRON_INGOT, 670, true),
		array(Item::GOLD_INGOT, 690, true),
		array(Item::DIAMOND, 700, false),
		array(Item::IRON_HELMET, 718, false),
		array(Item::IRON_CHESTPLATE, 724, false),
		array(Item::IRON_LEGGINGS, 736, false),
		array(Item::IRON_BOOTS, 754, false),
		array(Item::GOLD_HELMET, 778, false),
		array(Item::GOLD_CHESTPLATE, 796, false),
		array(Item::GOLD_LEGGINGS, 814, false),
		array(Item::GOLD_BOOTS, 838, false),
		array(Item::LEATHER_CAP, 868, false),
		array(Item::LEATHER_TUNIC, 892, false),
		array(Item::LEATHER_PANTS, 916, false),
		array(Item::LEATHER_BOOTS, 946, false),
		array(Item::CHAIN_HELMET, 967, false),
		array(Item::CHAIN_CHESTPLATE, 976, false),
		array(Item::CHAIN_LEGGINGS, 985, false),
		array(Item::CHAIN_BOOTS, 1000, false)
	);
	
	
	/**
	 * Check for tournament sign by coords
	 * 
	 * @param int $x
	 * @param int $y
	 * @param int $z
	 * @return bool
	 */
	public static function isTournamentSign($x, $y, $z) {
		return $y === self::$tournamentTiles["y"] && 
			$z === self::$tournamentTiles["z"] &&
			$x >= self::$tournamentTiles["xFirst"] && 
			$x <= self::$tournamentTiles["xLast"];
	}
	
	
	/**
	 * Check for TeamTile by coords
	 * 
	 * @param int $x
	 * @param int $y
	 * @param int $z
	 * @return bool
	 */
	public static function isTeamTile($x, $y, $z) {
		return ($x === self::$teamTileCoords["xLeft"] ||
			$x === self::$teamTileCoords["xRight"]) &&
			$z === self::$teamTileCoords["z"] &&
			self::getTeamByCoord($y);
	}
	
	/**
	 * Check what team is on activated sign (difference only in Y coord)
	 * 
	 * @param int $y
	 * @return string
	 */
	public static function getTeamByCoord($y) {
		if (isset(self::$TeamByCoordY[$y])) {
			return self::$TeamByCoordY[$y];
		}
		return false;
	}
}