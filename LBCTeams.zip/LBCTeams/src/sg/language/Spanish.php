<?php
namespace sg\language;

use pocketmine\utils\TextFormat;
use LbCore\language\core\Spanish as LbSpanish;

/**
 * Class contains specific plugin translates, 
 * add them into parent LbCore array $translates
 */
class Spanish extends LbSpanish {

	public function __construct() {
		/*Tournament signs*/
		$this->translates["ALREADY_STARTED"] = "§dEl juego ya ha comenzado.";
		$this->translates["TOURNAMENT_STOPPED"] = "§1- §dEl servidor no está funcionando.";
		$this->translates["ALMOST_FULL"] = "§1- §7 Ese juego está restringido para los §6VIP§7s,\n§1- §7esta casi lleno.";
		$this->translates["FULL"] = "§dEl juego está lleno.";
		/* Tournament */
		$this->translates["WON_MATCH"] = "§9> §farg1 §6ganó el juego.\n§9> §7Regresando a la sala de espera...";
		$this->translates["WON_MATCH_BROADCAST"] = "§aarg1 ganó el juego en la arena SG-arg2.";
		$this->translates["PLAYER_DEATH"] = "§barg1 §3matado por §farg2§3. §barg3 §3quedan jugadores.";
		$this->translates["GOOD_LUCK_MSG"] = "Sólo quedan dos jugadores.¡Buena suerte!";
		$this->translates["FIRST_KILL"] = "§aarg1 §5tuvo la primera matanza!";
		$this->translates["SUCCESS_MSG_1"] = "§aarg1¡arg1 está acabando!";
		$this->translates["SUCCESS_MSG_2"] = "§aarg1¡arg1 está §9#ganando§a!";
		$this->translates["SUCCESS_MSG_3"] = "§aarg1¡arg1 está en una oleada de asesinatos!";
		$this->translates["SUCCESS_MSG_4"] = "§aarg1¡arg1 lo esa haciendo muy bien!";
		$this->translates["MATCH_RESTARTING"] = "> Terminó la partida. ¡Gracias por jugar!\n> Reiniciando el servidor...";
		$this->translates["STARTING_IN"] = "§9> §7La partida empezará en: §farg1§7.";
		$this->translates["TOURNAMENT_START"] = "§9> §6¡El juego ha comenzado!";
		$this->translates["USING_MAP"] = "§9> §bUsando el mapa: arg1";
		$this->translates["USING_MAP_CREATOR"] = "§9>§7 Usando el mapa: arg1 by arg2";
		$this->translates["INVINCIBILITY_30"] = "§9> §3Tienes §e30§3 segundos de invencibilidad.";
		$this->translates["INVINCIBILITY_15"] = "§9> §3Quedan §e15§3 segundos de invencibilidad.";
		$this->translates["INVINCIBILITY_END"] = "§9> §3Ya no eres invencible.";
		$this->translates["CHEST_REFILL"] = "§9>§7 §e¡Los cofres han sidos rellenados!";
		$this->translates["DEATHMATCH_START"] = "§9>§7 Llegamos al combate final. ¡Qué el mejor jugador gane!";
		$this->translates["STARTING"] = "§9>§7 Comenzando en §earg1...";
		$this->translates["DEATHMATCH"] = "§9>§7 El combate final empezará en §earg1§3 minutos.";
		$this->translates["DM_COUNTDOWN"] = "§9>§7 El combate final empezará en §earg1§3...";
		$this->translates["ENDING"] = "§9>§7 El juego termina en §earg1§3 minutos.";
		$this->translates["JOINING"] = "§bEntrando al juego...";
		$this->translates["TOURNAMENT_WELCOME"] = "§b¡Bienvendo al juego!\n§bEmpezará en §3arg1§b.";
		$this->translates["ON_JOIN"] = "§9>§f arg1 §7ha entrado la partida.";
		$this->translates["PLAYERS_REMAIN"] = "arg1 jugadores se mantienen.";
		$this->translates["JUSTICE_MAP_WELCOME"] = TextFormat::GOLD . "Los kits están deshabilitados en este mapa.\n" 
				. TextFormat::GOLD . "Por lo tanto, no obtiene ningún arma, armadura o habilidades especiales.\n"
				. TextFormat::GOLD . "¡De miedo!";
		/*Commands*/
		$this->translates["RETURN_TO_LOBBY"] = "§1- §7Volviendo al vestíbulo.";
		$this->translates["LBTIME_ERROR"] = "§1- §7Unirse a un torneo de primera.";
		$this->translates["SHOW_LBTIME"] = "§1- §7El torneo comenzará en arg1.";
		/*VIP team signs*/
		$this->translates["ONLY_FOR_VIP"] = 
				TextFormat::RED . "Esta acción sólo está disponible para jugadores VIP.\n" . 
				TextFormat::RED . "Usted puede comprar rango VIP en la aplicación del bote salvavidas.";
		$this->translates["TEAM_CHANGED"] = 
				TextFormat::GOLD . "Equipo se cambia correctamente!\n" . 
				TextFormat::GOLD . "Su actual equipo es arg1";
	}

}
